<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AJAX</title>
    <script src="./src/view/script/script.js"></script>
</head>
<body>
    <h1>Aprendendo AJAX com Wagnin</h1>
    <span id="resposta"></span>
</body>
</html>